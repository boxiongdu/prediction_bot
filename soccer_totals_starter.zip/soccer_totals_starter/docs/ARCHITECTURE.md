# Module boundaries

| Module | Input | Output | Implementation status |
|---|---|---|---|
| providers/ | HTTP/WS payloads | raw envelopes + normalized snapshots | protocols, Kalshi offline parser only |
| storage.py | sanitized raw payload | append-only daily JSONL | implemented, single-writer design |
| mapping/ | fixture + market rules | verified mapping | domain type; matcher pending |
| features/ | received updates before decision | versioned feature row | pending |
| models.py | current goals + estimated remaining mean | Over probability | conversion only; training pending |
| pricing.py | probability + full book + fee estimate | cost and expected profit | offline math implemented |
| paper/ | decision + later market updates | partial fills or rejection | pending |
| validation/ | predictions, labels, fills | calibration and economic report | pending |

## Clock contract
UTC timezone-aware instants only. Keep event_at, received_at, decision_at, submitted_at, close_at and settled_at separate. Calendar dates never imply instants. The simulated decision sees only records with received_at <= decision_at. Preserve corrections; never replace an earlier snapshot with corrected final statistics.

## Market identity
Sportmonks fixture ID joins to a separately verified Kalshi ticker and event ticker. League IDs, team aliases and series tickers must be discovered, checked and allowlisted. Save rule text and mapping version. Require regulation + stoppage only, no extra time, and equivalent >2.5 total-goal condition. Unknown mappings produce no signal.

## Price contract
Use Decimal dollars per $1-payout contract and Decimal fixed-point quantities. Kalshi book normalization requires explicit orderbook_fp keys; incompatible schemas fail. YES asks come from 1 minus NO bids; NO asks come from 1 minus YES bids, with the same size. Sort prices explicitly. Price levels are not guaranteed fills. Unknown fees block production signals; demo fee is invented for arithmetic illustration only.

## Persistence and operations
Partition raw logs by provider/date; normalize into Parquet once schema is stable. Add DuckDB for research queries later. Single Python service initially; no Redis/Kafka required. Compress closed logs, enforce retention/disk thresholds, and preserve research snapshots. Never save auth headers, private keys or token-bearing request URLs. Redact tokens from provider pagination metadata before persistence. Add service health and reconnect logic before deployment.

## Extension contracts
features.build(snapshot_history, decision_at) -> feature row, provenance and freshness.
model.predict(features) -> probability, model version and training cutoff.
paper.evaluate(mapping, state, prediction, book, fee_schedule) -> signal or rejection reason.
paper.replay(signal, later_books, latency) -> fills; no same-instant assumed execution.
validation.evaluate(predictions, verified_labels) -> match-clustered statistics.

## Training and evaluation
Bundesliga + La Liga; prematch/halftime/60 minutes. One pooled model with league effects is a candidate, compare league-specific fits. Split chronologically by match and fit preprocessing/calibration only on designated development data. Log all variants. Later untouched matches and forward paper trading determine evidence of edge. Historical candles cannot validate exact live fills. At most one entry per match; fixed notional; hold to verified settlement.
