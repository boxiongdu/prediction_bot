import unittest
from datetime import datetime, timezone
from decimal import Decimal as D
from soccer_totals.providers.kalshi import normalize_book
from soccer_totals.models import over_probability
from soccer_totals.pricing import purchase_cost
from soccer_totals.domain import MarketMapping, MatchSnapshot

class CoreTests(unittest.TestCase):
    def test_opposite_bids_and_depth(self):
        b = normalize_book({"orderbook_fp": {"yes_dollars": [["0.3", "5"]],
            "no_dollars": [["0.5", "10"], ["0.6", "5"]]}}, "X", datetime.now(timezone.utc))
        self.assertEqual(purchase_cost(b, "yes", D(10)), D("4.5"))
        self.assertEqual(b.asks("no")[0].price, D("0.7"))
        with self.assertRaises(ValueError): purchase_cost(b,"yes",D(16))
    def test_known_probability(self):
        self.assertAlmostEqual(over_probability(1, 1.5), 0.44217459962892547)
        self.assertEqual(over_probability(3, 0), 1)
        self.assertEqual(over_probability(0, 0), 0)
    def test_mapping_blocks_unverified(self):
        with self.assertRaises(ValueError):
            MarketMapping("1","X",D("2.5"),True,False,True).require_verified()
    def test_naive_clock_rejected(self):
        with self.assertRaises(ValueError):
            MatchSnapshot("1","Bundesliga","HT",2700,0,0,datetime(2026,9,1))
if __name__ == "__main__": unittest.main()
