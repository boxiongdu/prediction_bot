import argparse, json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
import tomllib
from soccer_totals.providers.kalshi import normalize_book
from soccer_totals.models import over_probability
from soccer_totals.pricing import purchase_cost, expected_profit

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["check-config", "demo"])
    parser.add_argument("--config", default="config/project.toml")
    args = parser.parse_args()
    config = tomllib.loads(Path(args.config).read_text())
    if config["project"]["mode"] != "paper": raise ValueError("Only paper mode supported")
    if args.command == "check-config":
        print(json.dumps({"mode": "paper", "leagues": config["project"]["leagues"],
                          "live_connected": False, "trained_model": False}))
        return
    book = normalize_book({"orderbook_fp": {"yes_dollars": [["0.38", "100"]],
                           "no_dollars": [["0.60", "100"]]}},
                          "SYNTHETIC-NOT-A-REAL-MARKET", datetime.now(timezone.utc))
    p = over_probability(1, 1.5)
    cost = purchase_cost(book, "yes", Decimal(10))
    print(json.dumps({"synthetic_demo": True, "assumed_yes_means_over": True,
                      "assumed_remaining_mean": 1.5, "p_over": p,
                      "cost_10_contracts": str(cost),
                      "illustrative_fee": "0.05",
                      "hypothetical_expected_profit": str(expected_profit(
                          Decimal(str(p)), Decimal(10), cost, Decimal("0.05")))}))

if __name__ == "__main__": main()
