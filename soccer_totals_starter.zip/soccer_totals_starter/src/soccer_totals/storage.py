"""Append-only raw envelope writer. Caller supplies sanitized payloads, never auth URLs."""
import json
from pathlib import Path
from datetime import datetime, timezone

def append_raw(root: Path, provider: str, resource: str, payload: dict):
    if provider not in {"kalshi", "sportmonks"}: raise ValueError("Unknown provider")
    now = datetime.now(timezone.utc)
    path = root / provider / (now.date().isoformat() + ".jsonl")
    path.parent.mkdir(parents=True, exist_ok=True)
    envelope = {"provider": provider, "resource": resource,
                "received_at": now.isoformat(), "schema_version": 1, "payload": payload}
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(envelope) + "\n")
