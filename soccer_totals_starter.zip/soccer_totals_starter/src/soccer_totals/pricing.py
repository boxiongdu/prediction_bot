"""Depth-aware hypothetical purchase quote; not a fill simulator."""
from decimal import Decimal

def purchase_cost(book, side: str, quantity: Decimal) -> Decimal:
    if quantity <= 0: raise ValueError("Positive quantity required")
    remaining, cost = quantity, Decimal(0)
    for level in book.asks(side):
        take = min(remaining, level.quantity)
        cost += take * level.price
        remaining -= take
        if remaining == 0: return cost
    raise ValueError("Insufficient displayed depth")

def expected_profit(probability: Decimal, quantity: Decimal, cost: Decimal, fee: Decimal) -> Decimal:
    if not 0 <= probability <= 1 or quantity <= 0 or cost < 0 or fee < 0:
        raise ValueError("Invalid quote inputs")
    return probability * quantity - cost - fee
