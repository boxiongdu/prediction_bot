"""Offline wire normalization only; no authenticated connection or order submission."""
from decimal import Decimal
from soccer_totals.domain import BookSnapshot, Level

def normalize_book(payload: dict, ticker: str, received_at) -> BookSnapshot:
    book = payload["orderbook_fp"]
    def parse(key):
        return tuple(Level(Decimal(p), Decimal(q)) for p, q in book[key])
    return BookSnapshot(ticker, received_at, parse("yes_dollars"), parse("no_dollars"))
