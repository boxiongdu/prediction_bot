"""Adapters must normalize wire schemas before returning domain objects."""
from typing import Protocol, Iterable
from soccer_totals.domain import MatchSnapshot, BookSnapshot

class SportsFeed(Protocol):
    def snapshots(self) -> Iterable[MatchSnapshot]: ...

class MarketFeed(Protocol):
    def snapshots(self) -> Iterable[BookSnapshot]: ...
