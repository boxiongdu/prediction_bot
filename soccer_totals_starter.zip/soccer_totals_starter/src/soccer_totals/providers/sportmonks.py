"""Live adapter extension point. Do not infer field meanings from final-match data."""
class SportmonksAdapter:
    def snapshots(self):
        raise NotImplementedError(
            "Verify subscription, league IDs, periods and score/card schemas; "
            "implement pagination, receipt timestamps and correction handling first."
        )
