from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal

def aware(value):
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("Timezone-aware timestamp required")

@dataclass(frozen=True)
class MatchSnapshot:
    fixture_id: str
    league: str
    period: str
    elapsed_seconds: int
    home_goals: int
    away_goals: int
    received_at: datetime
    event_at: datetime | None = None
    home_red_cards: int = 0
    away_red_cards: int = 0
    def __post_init__(self):
        aware(self.received_at)
        if self.event_at is not None: aware(self.event_at)
        if min(self.elapsed_seconds, self.home_goals, self.away_goals,
               self.home_red_cards, self.away_red_cards) < 0:
            raise ValueError("Negative match state")

@dataclass(frozen=True)
class Level:
    price: Decimal
    quantity: Decimal
    def __post_init__(self):
        if not Decimal(0) <= self.price <= Decimal(1) or self.quantity <= 0:
            raise ValueError("Invalid book level")

@dataclass(frozen=True)
class BookSnapshot:
    ticker: str
    received_at: datetime
    yes_bids: tuple[Level, ...]
    no_bids: tuple[Level, ...]
    def __post_init__(self): aware(self.received_at)
    def asks(self, side: str) -> tuple[Level, ...]:
        if side not in ("yes", "no"): raise ValueError("Unknown side")
        bids = self.no_bids if side == "yes" else self.yes_bids
        return tuple(sorted((Level(Decimal(1)-x.price, x.quantity) for x in bids),
                            key=lambda x: x.price))

@dataclass(frozen=True)
class MarketMapping:
    fixture_id: str
    ticker: str
    line: Decimal
    yes_means_over: bool
    rules_verified: bool
    regulation_time_verified: bool
    def require_verified(self):
        if self.line != Decimal("2.5") or not self.rules_verified or not self.regulation_time_verified:
            raise ValueError("Unverified or out-of-scope contract")
