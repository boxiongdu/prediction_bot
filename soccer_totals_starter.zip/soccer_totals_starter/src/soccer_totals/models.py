"""Probability conversion, NOT a fitted forecasting model."""
import math

def over_probability(current_goals: int, remaining_mean: float, line: float = 2.5) -> float:
    if current_goals < 0 or int(current_goals) != current_goals:
        raise ValueError("Goals must be a nonnegative integer")
    if not math.isfinite(remaining_mean) or remaining_mean < 0:
        raise ValueError("Invalid remaining mean")
    if not math.isfinite(line) or line < 0 or line % 1 != 0.5:
        raise ValueError("Only nonnegative half-goal lines supported")
    needed = math.floor(line) + 1 - current_goals
    if needed <= 0: return 1.0
    term = math.exp(-remaining_mean)
    cumulative = term
    for k in range(1, needed):
        term *= remaining_mean / k
        cumulative += term
    return min(1.0, max(0.0, 1.0-cumulative))
