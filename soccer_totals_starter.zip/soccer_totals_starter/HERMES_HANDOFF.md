# Continue this scaffold

1. Run config check, demo and tests. Inspect existing files before extending them.
2. Read official Kalshi and Sportmonks API schemas. Verify installed API versions and subscription entitlements. Discover Bundesliga/La Liga IDs and matching Kalshi series/markets; never invent identifiers. Check current and historical market endpoints separately.
3. Implement read-only provider clients with pagination, rate limits, bounded retries, authentication where required, redaction, and raw response caching. Keep Kalshi signing isolated from research code. Use environment variables for Sportmonks token and paths to Kalshi keys; never print them.
4. Implement Sportmonks fixture history and live state normalization, including periods, stoppage, goals, cards and corrections. Explicitly audit historical point-in-time coverage.
5. Implement verified market matching and a recorder with reconnect/gap detection and UTC receipt timestamps. Use persistent supervisor only after local checks; report whether running or merely implemented.
6. Deliver DATA_COVERAGE.md with league seasons, fields, provider receipt-time limitations, market availability and blockers. Missing credentials should not block offline work. Do not purchase plans.
7. Build point-in-time features and the simple fitted goal model only after mapping/data gates pass. Add calibration, chronological evaluation, fees, latency-aware paper execution and settlement ingestion in later milestones.

Do not add real-money order submission, modify the whale bot, claim model training from the demo, or infer settlement from price thresholds. Existing components are a structure to extend, not evidence of profitable trading.

First handoff report: commands run, concrete outputs, provider connection status, uncovered schemas, and next implementation step.
