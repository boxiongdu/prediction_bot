# Soccer totals starter: Kalshi + Sportmonks

Python 3.11+, standard library only. This is an offline project scaffold, not a trained model or running recorder.

## Run from this folder
```bash
PYTHONPATH=src python -m soccer_totals.cli check-config
PYTHONPATH=src python -m soccer_totals.cli demo
PYTHONPATH=src python -m unittest discover -s tests -v
```
Optional editable install: `python -m pip install -e .` then use `soccer-totals demo`.

## Architecture
Sportmonks -> raw match updates -> normalized match state -> point-in-time features -> remaining-goals model.
Kalshi -> raw market/book updates -> verified fixture mapping -> executable quote.
Prediction + quote -> gated paper decision -> execution replay -> verified settlement -> validation.

Implemented: domain records, explicit mapping gate, Kalshi fixed-point book normalization, opposing-bid-to-ask conversion, depth-aware cost, Poisson probability conversion, raw JSONL writer, configuration and synthetic demo.
Not implemented: network collectors/authentication, historical backfills, fitted models, as-of feature engine, fee retrieval, paper fills, settlement ingestion, deployment.

See docs/ARCHITECTURE.md and HERMES_HANDOFF.md for module contracts and implementation order.

## Provider documentation checked 2026-09-17
- https://docs.kalshi.com/api-reference/market/get-markets
- https://docs.kalshi.com/api-reference/market/get-market-orderbook
- https://docs.sportmonks.com/v3/endpoints-and-entities/endpoints/livescores

Market existence and specific league/series identifiers are unverified. Empty allowlists are intentional. Capture the exact contract threshold and YES direction; never assume YES means Over.
